###########################
### model specification ###
###########################

# observed data #
numGroups=10
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# analysis information #
p0 = 0.10 #change according to p0
n.iter=40000
n.burnin=10000

# directories #
setwd("C:/Users/Haolin Li/Desktop/intern/04_code/zhou_2020")

################################
### analysis (DO NOT MODIFY) ###
################################

system("R CMD SHLIB fn_RoBoT_MCMC.cpp")
source("fn_RoBoT.R")
MCMC_spls = RoBoT_MCMC(n, x, p0, niter = n.iter, burnin = n.burnin, thin = 5, return_MCMC_spls = TRUE, alpha = 2)
pi_spls = MCMC_spls$pi_spls
PP = apply(pi_spls > p0, 1, sum) / dim(pi_spls)[2]
PM = apply(pi_spls, 1, mean)
PMD = apply(pi_spls, 1, median)
PM_lower = apply(pi_spls, 1, function(x){quantile(x, probs = 0.025)})
PM_upper = apply(pi_spls, 1, function(x){quantile(x, probs = 0.975)})
results = data.frame(post.prob = PP, post.mean=PM, post.median=PMD, post.CI.lower=PM_lower, post.CI.upper=PM_upper)
results
