###########################
### model specification ###
###########################

# observed data #
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# prior information #
mu0 = 0.5
phi0 = 1

# analysis information #
targetResp=0.1 #change according to p0

################################
### analysis (DO NOT MODIFY) ###
################################

library(bmabasket)
bma(pi0=targetResp, y=x, n=n, mu0 = mu0, phi0 = phi0)
