###########################
### model specification ###
###########################

# observed data #
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# prior information #
alpha <- 1e-20
d0 <- 0
alpha1 = 50
beta1 = 10
tau2 <- 0.1
p0 <- 0.1 #change according to p0
p1 <- 0.2 #change according to p1

# analysis information #
n.iter=40000
n.burnin=10000

################################
### analysis (DO NOT MODIFY) ###
################################

library(BCHM)
res <- BCHM(nDat = n, xDat = x, alpha = alpha, d0 = d0, alpha1 = alpha1, beta1 = beta1, tau2 = tau2, phi1 = p0, deltaT = p1-p0, thetaT = 0.01, burnIn = n.burnin, MCIter = n.iter, MCNum = 1000, seed = 1000)
print(res$SMatrix)
print(res$Result) # do not look at the "Decision" column
