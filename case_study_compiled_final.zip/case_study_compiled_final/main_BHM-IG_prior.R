###########################
### model specification ###
###########################

# observed data #
numGroups=10
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# prior information #
mean.Mu=-2.2 #change according to p0
perc.Mu=0.01
tau.alpha=0.0005
tau.beta=0.000005

# analysis information #
targetResp=0.1 #change according to p0
params = c("p", "pg")
n.iter=40000
n.burnin=10000

# directories #
setwd("C:/Users/Haolin Li/Desktop/intern/04_code/BHM-IG_prior")

################################
### analysis (DO NOT MODIFY) ###
################################

library(R2WinBUGS)
sink("mod1.txt")        
cat("model
 {
 for (i in 1:numGroups)
 {
 x[i] ~ dbin(p[i],n[i]);
 logit(p[i]) <- rho[i];
 rho[i] ~ dnorm(mu,tau)
 pg[i] <- step(p[i]- targetResp)
 }
 mu ~ dnorm(mean.Mu, perc.Mu)
 tau ~ dgamma(tau.alpha, tau.beta)
 }", fill = TRUE)
sink()
data = list(x=x, n=n, numGroups=numGroups, targetResp=targetResp, mean.Mu=mean.Mu, perc.Mu=perc.Mu, tau.alpha=tau.alpha, tau.beta=tau.beta)
inits <- function () {list(mu=1, tau=0.1)}
bugs.out <- bugs(data=data, inits=inits, parameters.to.save=params, model.file="mod1.txt", n.chains=2, n.iter=n.iter, n.burnin=n.burnin, debug=F, DIC=TRUE, bugs.directory = "C:\\Program Files\\WinBUGS14", working.directory=getwd())
print(bugs.out, digits = 3)



