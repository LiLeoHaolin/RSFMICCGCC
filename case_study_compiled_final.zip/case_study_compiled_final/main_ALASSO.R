###########################
### model specification ###
###########################

# observed data #
numGroups=10
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# tunning parameters #
lambda = 0.0018
gamma = 1.5 # change this to 0.2 for interim analysis

# analysis information #
cutoff = 0.10

################################
### analysis (DO NOT MODIFY) ###
################################

library(glmnet)
library(gtools)
basket_aLasso<-function(y,n,lambda,gamma){
  if(length(y)<2){
    stop("y should be a vector of length 2 or more")
  } 
  if(length(y)!=length(n)){
    stop("The vectors y and n should have the same length")
  }
  if(lambda<0 | gamma<0){
    stop("lambda and gamma should be non-negative")
  }
  K<- length(y)
  I<-diag(rep(1,K))
  pEst<-rep(NA,K)
  for(l in 1:K){
    if(y[l]==0){
      pEst[l]<-0
    } else if(y[l]==n[l]) {
      pEst[l]<-1
    } else {
      penFactor<- abs(logit((y[-l]/n[-l]))-logit((y[l]/n[l])))
      penFactor[abs(penFactor)==Inf]<-999
      include<-which(penFactor!=0)
      penFactor<-penFactor[include]
      penFactor<-(penFactor^(-gamma))
      XNew<-I[,-l]
      XNew<-XNew[,include]
      if(length(include)==0){
        fit<-glm(cbind(y,n-y)~1,family=binomial())
      } else if(length(include)==1){
        lambdaNew<- lambda*sum(penFactor)/length(include)
        fit <- glmnet(cbind(1,XNew), cbind(n-y,y), family = "binomial", 
                      intercept=T, 
                      standardize=F, 
                      lambda=lambdaNew, 
                      penalty.factor = c(0,penFactor))
      } else {
        lambdaNew<- lambda*sum(penFactor)/length(include)
        fit <- glmnet(XNew, cbind(n-y,y), family = "binomial", intercept=T, 
                      standardize=F, 
                      lambda=lambdaNew, 
                      penalty.factor = penFactor)
      }
      pEst[l]<-inv.logit(coef(fit)[1])
    }
  }
  return(pEst)
}
p = basket_aLasso(x,n,lambda,gamma)
pg = as.numeric(p>rep(cutoff, numGroups))
result = data.frame(p, pg)
print(result)

