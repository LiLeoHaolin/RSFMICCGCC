###########################
### model specification ###
###########################

# observed data #
numGroups=10
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# analysis information #
p0 = 0.10 #change according to p0

################################
### analysis (DO NOT MODIFY) ###
################################

library(basket)
results <- basket(x, n, c(1:numGroups), p0, cluster_analysis = TRUE)
summary(results)