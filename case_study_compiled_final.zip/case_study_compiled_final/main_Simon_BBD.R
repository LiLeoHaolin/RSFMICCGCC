###########################
### model specification ###
###########################

# observed data #
numGroups=10
x =c(2,0,1,6,7,3,5,1,0,3)
n =c(15,13,12,28,29,29,26,5,2,20)

# prior information #
lambda = 0.33
gamma = 0.5

# analysis information #
plo = 0.1 #change according to p0
phi = 0.2 #change according to p1

################################
### analysis (DO NOT MODIFY) ###
################################

find_postk <- function(lambda, gamma, r, n, plo, phi){
  P0.num <- (1-gamma)*prod(dbinom(r, n, plo))
  P0.deno <- gamma*prod(dbinom(r, n, phi))
  P0 <- 1/(1 + (P0.num/P0.deno))
  Pk.num <- gamma*dbinom(r, n, phi)
  Pk.deno <- gamma*dbinom(r, n, phi) + (1-gamma)*dbinom(r, n, plo)
  Pk <- Pk.num/Pk.deno
  pi1.num <- (1-lambda)*prod(gamma*dbinom(r, n, phi) + (1-gamma)*dbinom(r, n, plo))
  pi1.deno <- lambda*(gamma*prod(dbinom(r, n, phi)) + (1-gamma)*prod(dbinom(r, n, plo)))
  pi1 <- 1/(1+(pi1.num/pi1.deno))
  postk <- P0*pi1 + Pk*(1 - pi1)
  postk
}
p.active = find_postk(lambda=lambda, gamma=gamma, r=x, n=n, plo=plo, phi=phi)
post.mean = p.active*phi + (1-p.active)*plo
result = data.frame(p.active, post.mean)
result

